document.addEventListener('DOMContentLoaded', function () {

    let gleamPart = document.getElementById('gleamPart');   
    let donePart = document.getElementById('donePart');
    let cookies = document.cookie;
    
 
    if (cookieExists('ethAddress')) {
        // If cookies exist, change the display type to block
        gleamPart.style.display = 'none';
        donePart.style.display = 'block';
    } else {
        // If no cookies exist, change the display type to none
        donePart.style.display = 'none';
        gleamPart.style.display = 'block';
    }

});




// Function to handle scroll event
function handleScroll() {
    // Get the scroll position of the page
    let scrollPosition = window.pageYOffset;



    let scaleValue1 = 2 - scrollPosition * 0.003;
    if (scaleValue1 < 1) {
        scaleValue1 = 1;
    }


    const layer0 = document.querySelector('.layer0');
    const layer1 = document.querySelector('.layer1');
    const layer2 = document.querySelector('.layer2');
    const layer3 = document.querySelector('.layer3');
    layer0.style.backgroundSize = `${scaleValue1 * 100}%`;
    layer1.style.backgroundSize = `${scaleValue1 * 100}%`;
    layer2.style.backgroundSize = `${scaleValue1 * 100}%`;
    layer3.style.backgroundSize = `${scaleValue1 * 100}%`;
    layer0.style.backgroundPosition = `50% ${scrollPosition * 0.7}px`;
    layer1.style.backgroundPosition = `50% ${scrollPosition * 0.6}px`;
    layer2.style.backgroundPosition = `50% ${scrollPosition * 0.5}px`;
    layer3.style.backgroundPosition = `50% ${scrollPosition * 0.4}px`;
   // layer1.style.backgroundPositionY = `calc(50% + ${parallaxValue}px)`;
    // window.addEventListener('scroll', function() {
    //     const scrollValue = window.scrollY;
    //     const bottomSection = document.querySelector('.bottom-section');
    //     // Calculate the zoom level based on scroll position
    //     const zoomLevel = 2 - scrollValue / window.innerHeight;
    //     // Apply the zoom effect to the background image
    //     bottomSection.style.backgroundSize = `${zoomLevel * 100}%`;
    //     // Apply parallax scrolling effect
    //     const parallaxValue = scrollValue * 0.5; // Adjust the parallax speed as needed
    //     bottomSection.style.backgroundPositionY = `calc(50% + ${parallaxValue}px)`;
}

// Attach scroll event listener to the window
window.addEventListener('scroll', handleScroll);

function cookieExists(name) {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();
        if (cookie.indexOf(name + '=') === 0) {
            return true;
        }
    }
    return false;
}